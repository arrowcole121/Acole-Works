var match_running = false;
var have_been_in_teleop = false;
var match = null;
var updateIntervalID = null;

var hostname = "test.mosquitto.org";
var port = 8080; // only supports websockets

mqttClient = new Paho.MQTT.Client(hostname, port, "livescore-" + guid());

// set callback handlers
mqttClient.onConnectionLost = onConnectionLost;
mqttClient.onMessageArrived = onMessageArrived;

// connect the client
mqttClient.connect({onSuccess:onConnect, onFailure:displayError, reconnect: true});


// called when the client connects
function onConnect() {
    console.log("onConnect");
    mqttClient.subscribe("/livescore/match");
    mqttClient.subscribe("/field/1/time");
    mqttClient.subscribe("/field/2/time");
    mqttClient.subscribe("/field/1/opmode");
    mqttClient.subscribe("/field/2/opmode");
    $("#error-message").hide();
}

function displayError() {
    $("#error-message").show();
}

// called when the client loses its connection
function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0) {
        $("#error-message").show();
    }
}

// called when a message arrives
function onMessageArrived(message) {
    if (message.destinationName == "/field/1/time" || message.destinationName == "/field/2/time") {
        minutes = Math.floor(Number(message.payloadString) / 60);
        seconds = Number(message.payloadString) - 60 * minutes;
        $(".time").text(minutes + ":" + pad(seconds, 2));
    } else if (message.destinationName == "/field/1/opmode" || message.destinationName == "/field/2/opmode") {
        if (message.payloadString == "teleop") {
            have_been_in_teleop = true;
        }
        
        if (message.payloadString != "disabled" && !match_running) {
            match_running = true;
            updateIntervalID = setInterval(periodicallyUpdateApproxScore, 2000);
            if (currentPage() == "waiting") {
                toPage("auto");
            }
        } else if (message.payloadString == "disabled" && match_running && have_been_in_teleop) {
            match_running = false;
            have_been_in_teleop = false;
            clearInterval(updateIntervalID);
        }
    } else if (message.destinationName == "/livescore/match" && !match_running)  {
        match = Number(message.payloadString);
        $(".match").text("Match " + match);
        $("#summary-header").text("Match " + match + " Summary");
    }
}

function periodicallyUpdateApproxScore() {
    message = new Paho.MQTT.Message(String(get_current_score()));
    message.destinationName = alliance == Alliance.red ? "/livescore/red-update" : "/livescore/blue-update";
    mqttClient.send(message);
}

function pad(num, size) {
    var s = num+"";
    while (s.length < size) s = "0" + s;
    return s;
}

function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}