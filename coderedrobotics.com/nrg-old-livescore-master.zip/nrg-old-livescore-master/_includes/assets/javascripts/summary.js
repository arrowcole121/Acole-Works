var auto_attempts = 0;
var auto_crosses = 0;

function goto_summary() {
    if (robot_1_attempted) {
        auto_attempts++;
    }
    if (robot_2_attempted) {
        auto_attempts++;
    }
    
    if (robot_1_crossed) {
        auto_crosses++;
    }
    if (robot_2_crossed) {
        auto_crosses++;
    }
    
    if (wreckage_knocked_over == -1 || wreckage_knocked_over == null) {
        wreckage_knocked_over = 4;
    }
    
    $('#summary-auto-attempts').text("Auto Attempts: " + auto_attempts);
    $('#summary-wreckage').text("Tipped Wreckage: " + (wreckage_knocked_over == 4 ? "Many" : wreckage_knocked_over));
    $('#summary-auto-crossings').text("Auto Crossings: " + auto_crosses);
    $('#summary-crosses').text("Crosses: " + crosses);
    $('#summary-crosses-with-part').text("Crosses w/ Part: " + crosses_with_part);
    $('#summary-blue-parts').text("Blue Spare Parts: " + blue_spare_parts);
    $('#summary-red-parts').text("Red Spare Parts: " + red_spare_parts);
    switch (endgame_generator_state) {
        case EndgameState.OneContacting:
            $('#summary-endgame-generator-state').text("1 Robot Contacting");
            break;
        case EndgameState.TwoContacting:
            $('#summary-endgame-generator-state').text("2 Robots Contacting");
            break;
        case EndgameState.OneBalanced:
            $('#summary-endgame-generator-state').text("1 Robot Balanced");
            break;
        case EndgameState.TwoBalanced:
            $('#summary-endgame-generator-state').text("2 Robots Balanced");
            break;
        default:
            $('#summary-endgame-generator-state').text("No Contact or Balance");
            break;
    }
    $('#summary-fouls').text("Fouls: " + fouls);
    $('#summary-tech-fouls').text("Tech Fouls: " + tech_fouls);
    
    toPage("summary");
}

function inc_auto_attempts() {
    auto_attempts++;
    if (auto_attempts > 2) {
        auto_attempts = 2;
    }
    $('#summary-auto-attempts').text("Auto Attempts: " + auto_attempts);
}

function dec_auto_attempts() {
    auto_attempts--;
    if (auto_attempts < 0) {
        auto_attempts = 0;
    }
    $('#summary-auto-attempts').text("Auto Attempts: " + auto_attempts);
}

function inc_wreckage() {
    wreckage_knocked_over++;
    if (wreckage_knocked_over == 2) {
        wreckage_knocked_over = 3;
    }
    if (wreckage_knocked_over > 3) {
        wreckage_knocked_over = 4;
    }
    $('#summary-wreckage').text("Tipped Wreckage: " + (wreckage_knocked_over == 4 || wreckage_knocked_over == null ? "Many" : wreckage_knocked_over));
}

function dec_wreckage() {
    wreckage_knocked_over--;
    if (wreckage_knocked_over == 2) {
        wreckage_knocked_over = 1;
    }
    if (wreckage_knocked_over <  0) { 
        wreckage_knocked_over = 0;
    }
    $('#summary-wreckage').text("Tipped Wreckage: " + (wreckage_knocked_over == 4 || wreckage_knocked_over == null ? "Many" : wreckage_knocked_over));
}

function inc_auto_crossings() {
    auto_crosses++;
    if (auto_crosses > 2) {
        auto_crosses = 2;
    }
    $('#summary-auto-crossings').text("Auto Crossings: " + auto_crosses);
}

function dec_auto_crossings() {
    auto_crosses--;
    if (auto_crosses < 0) {
        auto_crosses = 0;
    }
    $('#summary-auto-crossings').text("Auto Crossings: " + auto_crosses);
}

function inc_crosses() {
    crosses++;
    $('#summary-crosses').text("Crosses: " + crosses);
}

function dec_crosses() {
    crosses--;
    if (crosses < 0) {
        crosses = 0;
    }
    $('#summary-crosses').text("Crosses: " + crosses);
}

function inc_crosses_with_part() {
    crosses_with_part++;
    $('#summary-crosses-with-part').text("Crosses w/ Part: " + crosses_with_part);
}

function dec_crosses_with_part() {
    crosses_with_part--;
    if (crosses_with_part < 0) {
        crosses_with_part = 0;
    }
    $('#summary-crosses-with-part').text("Crosses w/ Part: " + crosses_with_part);
}

function inc_red_parts() {
    red_spare_parts++;
    if (red_spare_parts > 15) {
        red_spare_parts = 15;
    }
    $('#summary-red-parts').text("Red Spare Parts: " + red_spare_parts);
}

function dec_red_parts() {
    red_spare_parts--;
    if (red_spare_parts < 0) {
        red_spare_parts = 0;
    }
    $('#summary-red-parts').text("Red Spare Parts: " + red_spare_parts);
}

function inc_blue_parts() {
    blue_spare_parts++;
    if (blue_spare_parts > 15) {
        blue_spare_parts = 15;
    }
    $('#summary-blue-parts').text("Blue Spare Parts: " + blue_spare_parts);
}

function dec_blue_parts() {
    blue_spare_parts--;
    if (blue_spare_parts < 0) {
        blue_spare_parts = 0;
    }
    $('#summary-blue-parts').text("Blue Spare Parts: " + blue_spare_parts);
}

function inc_endgame_state() {
    endgame_generator_state++;
    if (endgame_generator_state > 4) {
        endgame_generator_state = 4;
    }
    
    switch (endgame_generator_state) {
        case EndgameState.OneContacting:
            $('#summary-endgame-generator-state').text("1 Robot Contacting");
            break;
        case EndgameState.TwoContacting:
            $('#summary-endgame-generator-state').text("2 Robots Contacting");
            break;
        case EndgameState.OneBalanced:
            $('#summary-endgame-generator-state').text("1 Robot Balanced");
            break;
        case EndgameState.TwoBalanced:
            $('#summary-endgame-generator-state').text("2 Robots Balanced");
            break;
        case 0:
            $('#summary-endgame-generator-state').text("No Contact or Balance");
            break;
    }
}

function dec_endgame_state() {
    endgame_generator_state--;
    
    if (endgame_generator_state < 0) {
        endgame_generator_state = 0;
    }
    
    switch (endgame_generator_state) {
        case EndgameState.OneContacting:
            $('#summary-endgame-generator-state').text("1 Robot Contacting");
            break;
        case EndgameState.TwoContacting:
            $('#summary-endgame-generator-state').text("2 Robots Contacting");
            break;
        case EndgameState.OneBalanced:
            $('#summary-endgame-generator-state').text("1 Robot Balanced");
            break;
        case EndgameState.TwoBalanced:
            $('#summary-endgame-generator-state').text("2 Robots Balanced");
            break;
        case 0:
            $('#summary-endgame-generator-state').text("No Contact or Balance");
            break;
    }
}

function inc_fouls() {
    fouls++;
    $('#summary-fouls').text("Fouls: " + fouls);
}

function dec_fouls() {
    fouls--;
    if (fouls < 0) {
        fouls = 0;
    }
    $('#summary-fouls').text("Fouls: " + fouls);
}

function inc_tech_fouls() {
    tech_fouls++;
    $('#summary-tech-fouls').text("Tech Fouls: " + tech_fouls);
}

function dec_tech_fouls() {
    tech_fouls--;
    if (tech_fouls < 0) {
        tech_fouls = 0;
    }
    $('#summary-tech-fouls').text("Tech Fouls: " + tech_fouls);
}