var Alliance = {"red":1, "blue":2};
Object.freeze(Alliance);

var EndgameState = {"OneContacting":1, "TwoContacting":2, "OneBalanced":3, "TwoBalanced":4};
Object.freeze(EndgameState);

// auto
var alliance = null;
var robot_1_attempted = false;
var robot_2_attempted = false;
var wreckage_knocked_over = null;
var robot_1_crossed = false;
var robot_2_crossed = false;

// teleop
var crosses = 0;
var crosses_with_part = 0;
var spare_part_approximation = 0;

// endgame
var blue_spare_parts = 0;
var red_spare_parts = 0;
var endgame_generator_state = null;

var fouls = 0;
var tech_fouls = 0;

var toggle_groups = {};
var undo_stack = [];

$(document).ready(function() {
    reset();
    
   $(document).on('input', ':input[type="range"]', function() {
       $('#' + $(this).attr('id') + '-value').text( $(this).val() );
       if ($(this).val() > 7) {
           $('#' + $(this).attr('id') + '-value').css("color", "white");
       } else {
           $('#' + $(this).attr('id') + '-value').css("color", "#202020");
       }
       
       if ($(this).attr('id') == "red-spare-parts") {
           red_spare_parts = $(this).val();
       } else if ($(this).attr('id') == "blue-spare-parts") {
           blue_spare_parts = $(this).val();
       }
   });
});

function set_alliance(type) {
//    request_full_screen();
    
    if (type == alliance) {
        toPage("waiting");
        return;
    }
    if (alliance == null && type == Alliance.blue) {
        toPage("waiting");
        alliance = Alliance.blue;
        return;
    }
    
    update_displayed_alliance(type);
    
    toPage("waiting");
}

function update_displayed_alliance(type) {
    alliance = type;
    $('.red').addClass('blue-intermediate').removeClass('red');
    $('.text-red').addClass('text-blue-intermediate').removeClass('text-red');
    $('.blue').addClass('red').removeClass('blue');
    $('.text-blue').addClass('text-red').removeClass('text-blue');
    $('.blue-intermediate').addClass('blue').removeClass('blue-intermediate');
    $('.text-blue-intermediate').addClass('text-blue').removeClass('text-blue-intermediate');
    
    if (alliance == Alliance.blue) {
        $('.alliance').text("BLUE ALLIANCE");
        $('#switch_to').text("Switch to Red");
    } else {
        $('.alliance').text("RED ALLIANCE");
        $('#switch_to').text("Switch to Blue");
    }
}

function request_full_screen() {    
    var doc = window.document;
    var docEl = doc.documentElement;

    var requestFullScreen = docEl.requestFullscreen || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;

    if(!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
        requestFullScreen.call(docEl);
    }
}

function toggle_button(caller, property) {
    if (property) {
        caller.style.background = "#27C300";
    } else {
        caller.style.background = ""
    }
}

function toggle_group_button(caller, button_value, group_class) {
    var highlight = true;
    var new_value = button_value;
    if (group_class in toggle_groups && toggle_groups[group_class] == caller) {
        highlight = false;
        new_value = null;
        toggle_groups[group_class] = null;
    } else {
        toggle_groups[group_class] = caller;
    }
    
    $("." + group_class).css("background", "");
    if (highlight) {
        caller.style.background = "#27C300";
    }
    
    return new_value;
}

function foul() {
    fouls++;
    $('.foul').text("Foul (" + fouls + ")");
    $('.undo').show();
    undo_stack.push({ 'action': function() {
        fouls--;
    }});
}

function tech_foul() {
    tech_fouls++;
    $('.tech-foul').text("Tech Foul (" + tech_fouls + ")");
    $('.undo').show();
    undo_stack.push({ 'action': function() {
        tech_fouls--;
    }});
}

function count_cross() {
    crosses++;
    $('.cross').text("Cross (" + crosses + ")");
    $('.undo').show();
    undo_stack.push({ 'action': function() {
        crosses--;
    }});
}

function count_cross_with_part() {
    crosses_with_part++;
    $('.cross_with_part').html("Cross</br>w/ Part (" + crosses_with_part + ")");
    $('.undo').show();
    undo_stack.push({ 'action': function() {
        crosses_with_part--;
    }});
}

function undo() {
    if (undo_stack.length == 0) {
        return;
    }
    
    undo_stack.pop()['action']();
    $('.foul').text("Foul (" + fouls + ")");
    $('.tech-foul').text("Tech Foul (" + tech_fouls + ")");
    $('.cross').text("Cross (" + crosses + ")");
    $('.cross_with_part').html("Cross</br>w/ Part (" + crosses_with_part + ")");
    
    if (undo_stack.length == 0) {
        $('.undo').hide();
    }
}

function toggle_alliance() {
    var toggle = confirm("This will reset any data you have entered for this match. Are you sure?");
    if (toggle) {
        reset();
        update_displayed_alliance(alliance == Alliance.red ? Alliance.blue : Alliance.red);
    }
}

function get_current_score() {
    return -1; // TODO
}

function reset() {
    robot_1_attempted = false;
    robot_2_attempted = false;
    wreckage_knocked_over = null;
    robot_1_crossed = false;
    robot_2_crossed = false;

    // teleop
    crosses = 0;
    crosses_with_part = 0;
    spare_part_approximation = 0;

    // endgame
    blue_spare_parts = 0;
    red_spare_parts = 0;
    endgame_generator_state = null;

    fouls = 0;
    tech_fouls = 0;

    toggle_groups = {};
    undo_stack = [];
    
    auto_attempts = 0;
    auto_crosses = 0;
    
    $('.foul').text("Foul (" + fouls + ")");
    $('.tech-foul').text("Tech Foul (" + tech_fouls + ")");
    $('.cross').text("Cross (" + crosses + ")");
    $('.cross_with_part').html("Cross</br>w/ Part (" + crosses_with_part + ")");
    $('.highlightable').css("background", "");
    $(':input[type="range"]').val(0);
    $(".range-value").text(0);
    $(".range-value").css("color", "#202020")
}

function upload() {
    toPage("waiting");
    
    var data = {};
    data.auto_attempts = auto_attempts;
    data.wreckage_knocked_over = wreckage_knocked_over;
    data.auto_crossings = auto_crosses;
    data.crossings = crosses;
    data.crossings_with_part = crosses_with_part;
    data.blue_spare_parts = blue_spare_parts;
    data.red_spare_parts = red_spare_parts;
    data.endgame_state = endgame_generator_state;
    data.fouls = fouls;
    data.tech_fouls = tech_fouls;
    
    message = new Paho.MQTT.Message(JSON.stringify(data));
    message.destinationName = alliance == Alliance.red ? "/livescore/red" : "/livescore/blue";
    mqttClient.send(message);
    
    reset();
}