var MaxPages = 100;
var pageHistory = [];


$(document).ready(function() {
    toPage('choose_alliance');
});

function toPage(page,isPrev) {
    //Hide all elements from current page
    $('#' + pageHistory[pageHistory.length-1]).hide();
    //Show all elements from new page
    $('#navbar, #' + page ).show();
    
    undo_stack = [];
    $('.undo').hide();

    //Check if we are returning to a previous page, also check for cycles of 2 pages, IE switching back and forth
    //  between home and help, no reason to save this...
    if(!isPrev && !(pageHistory[pageHistory.length - 2] === page)) {
        //Do not add to stack if we are going to the same page (spam home page)
        if(pageHistory[pageHistory.length-1] !== page) {
            //If max # of pages to save, remove from front of stack to make room.
            if (pageHistory.length === MaxPages) {
                pageHistory.shift();
            }
            pageHistory.push(page);
        }
    } else {
        //We are returning to previous page, pop page from stack
        pageHistory.pop();
    }

    //If no pages to go back to, remove back button
    pageHistory.length === 1 ? $('#back').hide() : $('#back').show();
}

function previousPage() {
    //Check to make sure we have a page to go back to, we should always have at least one page in history
    if(pageHistory.length > 1) {
        toPage(pageHistory[pageHistory.length - 2], true);
    }
}

function currentPage() {
    if (pageHistory.length > 0) {
        return pageHistory[pageHistory.length - 1]
    }
    return null;
}

function toggleHide(hide){
    var divs = $('.hideable');
    hide ? divs.hide() : divs.show();
}